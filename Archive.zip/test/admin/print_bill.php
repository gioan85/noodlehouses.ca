
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>noodlehouses.ca</title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script type="text/javascript" src="js/jquery.js"></script>

<style type="text/css">
	body{ margin:0px; overflow:hidden; padding:10px; width:100%; font-family: Arial, Helvetica, sans-serif;}
    table{ width:100%;}
    table td{ text-align:center; font-size:14px; color:#000; line-height:18px; width:15%; text-transform: uppercase;}
    table td:nth-child(1){ width:55%; text-align:left !important;}
    table td:nth-last-child(1){ text-align:right; padding-right:5%; width:10%;}
    table tr.border td{border-top:1px dashed #000; border-bottom:1px dashed #000; padding:5px 0px;}
    table tr.header td{ font-size:14px; padding:10px 0px;}
    table.print_content td{ text-align:center !important;}
    #print_mid tr:nth-child(1) td{font-size: 12px;}
    #print_header tr:nth-last-child(1) td{ text-align: left !important; }
    @page{ size:auto; margin:10%;}

</style>
</head>

<body id="print_bill_content_">

</body>

</html>
