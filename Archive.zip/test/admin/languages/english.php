<?php

define('TITLE_ALL' , 'This Title is All');
define('DESCRIPTION_ALL' , 'This is Desc All');
define('KEYWORDS_ALL' , 'This is Keywords All');

?>