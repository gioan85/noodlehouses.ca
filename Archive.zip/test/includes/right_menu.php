<ul>
  <div style="clear:both; text-align:center; margin:5px 0;"><strong>Miền Bắc</strong><br /><a href="ymsgr:SendIM?le.quangnam" title="Kinh doanh miền Bắc"><IMG alt="Kinh doanh miền Bắc" src="http://opi.yahoo.com/online?u=le.quangnam&m=g&t=2&l=us&opi.jpg" border=0></a></div>
  
  
  <div style="clear:both; text-align:center; margin:5px 0;"><strong>Miền Nam</strong><br /><a href="ymsgr:SendIM?kinhdoanh_buffalo" title="Kinh doanh miền Nam"><IMG alt="Kinh doanh miền Nam" src="http://opi.yahoo.com/online?u=kinhdoanh_buffalo&m=g&t=2&l=us&opi.jpg" border=0></a></div>
  
  
  <div style="clear:both; text-align:center; margin:5px 0;"><strong>Kỹ thuật</strong><a href="ymsgr:SendIM?le.quangnam" title="Hỗ trợ kỹ thuật"><img src="http://opi.yahoo.com/online?u=le.quangnam&m=g&t=2&l=us&opi.jpg" alt="Hỗ trợ kỹ thuật" border="0"/></a></div>
  <li id="routingdownloads"><a href="http://download.buffalo.vn/" target="_blank">Tải về</a></li>
  <li id="routingforums"><a href="http://forums.buffalotech.com/" target="_blank">Diễn đàn</a></li>
  <div style="clear:both; height:367px;"></div>
</ul>