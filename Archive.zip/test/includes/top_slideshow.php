<script type="text/javascript" src="js/img_liveshow.js"></script>
<link href="templates/slide.css" rel="stylesheet" type="text/css" />
<div style="margin-bottom:10px;">
    <div class="slider-wrap" style=" overflow: hidden; background:#cdcdcd; width:760px; height:302px;">
        <div id="slider-content" class="slider-wrap">
            <img style=" display: block; z-index: 4; opacity: 0.000631522;" width="760" height="302" src="images/Shared_Storage_03.png" alt=""> 
            <img style=" display: block; z-index: 3; opacity: 0.999287;" width="760" height="302" src="images/NetworkStorage_03.png" alt=""> 
            <img style=" display: none; z-index: 3; opacity: 0; " width="760" height="302" src="images/USB3.0_Storeage_03.png" alt="">
            <img style=" display: none; z-index: 3; opacity: 0; " width="760" height="302" src="images/High_Power_03.png" alt="">
        </div>
    </div>
</div>