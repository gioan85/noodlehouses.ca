<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta name="google-site-verification" content=" v0_GZZh8xovyJiMB4IRgsMatfolff6scK422CshbbLs">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Buffalo Vietnam</title>
<meta name="keywords" content="THIET BI LUU TRU MANG, thiet bi luu tru mang, thiết bị lưu trữ mạng, Ổ cứng mạng, Back up, NAS Buffalo, Thiết bị mạng Buffalo, Ổ cứng mạng NAS Buffalo">

<meta name="description" content="THIET BI LUU TRU MANG, THIẾT BỊ LƯU TRỮ MẠNG, Ổ CỨNG MẠNG , AN TOÀN DỮ LIỆU , BACKUP, NAS , THIẾT BỊ MẠNG , Ổ CỨNG LẮP NGOÀi , THIẾT BỊ KHÔNG DÂY , WIFI , WIRELESS, O CUNG MANG , THIET BI LUU TRU MANG, ANTOAN DU LIEU , BACKUP , NAS , THIET BI MANG , O CUNG LAP NGOAI , THIET BI KHONG DAY , WIFI , WIRELESS, Giải pháp lưu trữ, giải pháp doanh nghiệp, an toàn dữ liệu, bảo vệ dữ liệu, cứu dữ liệu, đảm bảo, Ổ cứng mạng, thiết bị mạng, bộ định tuyến, bộ chuyển mạch, ổ cứng lắp ngoài, Chia sẻ lưu trữ, lưu trữ doanh nghiệp, lưu trữ cá nhân, lưu trữ gia đình, lưu trữ nghe nhìn, lưu trữ server, data center, office, data, backup, raid, medial server, multimedial, video, mucsic, picture, file server, server,Terastation , terastation pro, rackmount, linkstation, linkstation pro, drivestation, airstation, aistation pro, CloudStor™ Pro Shared Storage, linktheater, wireless, network, TS-HTGL, TS-XL, TS-WXL, TS-WVHL, TS-QVHL, TS-RVHL, TS-6VHL, TS-8VHL, WS-WVL, WS-QVL, WS-RVL, WS-6VL, TS-iGL, TS-RiGL, TS-IXL, TS-RIXL, CS-WV/1D,Network Attached Storage, iSCSI, SAN, NAS, ổ cứng hỗ trợ RAID, TB, Gigabit, Gigabyte, jbod, normal,  WebAccess và WebAccess i App iPhone iPad , DLNA Certified™ iTunes® Servers, BitTorrent® Client, MySQL server, Web server, Active Directory, Network Servers: FTP, TurboPC với Turbo Copy, IEEE802.3ab / IEEE802.3 / IEEE802.3u, CIFS/SMB, AFP, HTTP/HTTPS, FTP/SFTP, HTTP/HTTPS, CIFs/SMB, NFS, IIS, (FTP/FTPS, HTTP/HTTPS) , high performance, Windows Storage Server, Linux, Apple, Microsoft, iSCSI Target and Initiator, Internet Information Services (IIS) support, NovaBACKUP® Business Essentials, Windows Servers, Exchange or MS SQL databases">

<!-- begin google tracking script -->
<script src="js/jquery.js" async="" type="text/javascript"></script>

<script type="text/javascript">
var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-412084-2']);
_gaq.push(['_setDomainName', '.buffalotech.com']);
_gaq.push(['_trackPageview']);
(function() {
	var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();

	function setCookie(c_name,value,expiredays)
	{    
		var exdate=new Date()
		exdate.setDate(exdate.getDate()+expiredays)
		document.cookie=c_name+ "=" +escape(value)+
		((expiredays==null) ? "" : ";expires="+exdate.toGMTString());
	}
	
	$(document).ready(function() {		
		$("#<?php echo $_COOKIE['top_nav']; ?>").addClass("actived");
	 });	
	

</script>
<?php 
	$server = DB_SERVER;
	$user = DB_SERVER_USERNAME;
	$password = DB_SERVER_PASSWORD;
	$database = DB_DATABASE;
	
	tep_db_connect($server, $user, $password, $database);
	
	if(!isset($_COOKIE['nation']) && $_COOKIE['nation']=='')
	{
		//echo '<script type="text/javascript">';
		//echo "window.location.href = 'select_your_region.php';";
	}
	
?>
<!-- end google tracking script -->
<link href="templates/global.css" rel="stylesheet" type="text/css" />
<link href="templates/home.css" rel="stylesheet" type="text/css" />
<link href="templates/nav.css" rel="stylesheet" type="text/css" />
<link href="templates/products.css" rel="stylesheet" type="text/css" />

</head>

<body class="home">
<div id="floater">
    <div id="floater-trim1">
        <div id="floater-trim2">
            <div id="floater-trim3">        
                <div id="header"><a href="javascript:void(0);" onclick="setCookie('top_nav','trangchu');"><h1>Buffalo Technology</h1></a></div>            	
                <ul id="auxnav">
                	<li id="auxnavregion"><a href="javascript:void(0);">Select Your Region</a></li>
                </ul>
                <div id="search-form">             
                  	<div style="margin:10px 0 0 0 ;">
                      <input class="field" style="color:#666; float:left;" name="search_phrase" id="search_phrase" value="thông tin sản phẩm" onclick="if(document.getElementById('search_phrase').value=='thông tin sản phẩm') document.getElementById('search_phrase').value=''" onblur="if(document.getElementById('search_phrase').value=='') document.getElementById('search_phrase').value='thông tin sản phẩm'" type="text">
                      <input src="images/btn_search_nav.gif" style="" onclick="search_info();" name="search" type="image">
                 	</div>
                </div>
                
                <div id="top_nav">
                    <div class="left_bg">
                        <div class="right_bg">                        	
                        	<ul>
                            	<li><a href="trangchu.html" id="trangchu" <?php if($_COOKIE['top_nav'] =='trangchu') echo 'class="actived"'; ?> onclick="setCookie('top_nav','trangchu');">Trang Chủ</a></li>
                                <li class="space"></li>
                                <li><a href="c0-tong quan.html" id="sanpham" <?php if($_COOKIE['top_nav'] =='sanpham') echo 'class="actived"'; ?> onclick="setCookie('category','0',1); setCookie('top_nav','sanpham');" >Sản Phẩm</a>
                                	<ul>
                                    	<?php 
										$category = tep_db_query('select * from category');
										while($category_row = tep_db_fetch_array($category))
										{
											echo '<li><a href="c'.$category_row['ID'].'-'.$category_row['NAME'].'.html" onclick="setCookie('."'top_nav'".','."'sanpham'".');" >'. $category_row['NAME'] . '</a>';
											$sub_prod = tep_db_query('select * from sub_product where sub_product.CATEGORY_ID=' . $category_row['ID']);
											if($sub_prod != '')
											{
												echo '<ul class="child">';
												while($sub_prod_row = tep_db_fetch_array($sub_prod))
												{
													echo '<li><a href="s'.$sub_prod_row['ID'].'-'.$category_row['NAME'].'-'.$sub_prod_row['NAME'].'.html" onclick="setCookie('."'top_nav'".','."'sanpham'".');">'.$sub_prod_row['NAME'].'</a></li>';
												}
												echo '</ul>';
											}
											echo '</li>';
										}
										?>
                                    </ul>
                                </li>
                                <li class="space"></li>
                                <li><a href="congnghe.html" id="congnghe" <?php if($_COOKIE['top_nav'] =='congnghe') echo 'class="actived"'; ?> onclick="setCookie('top_nav','congnghe');">Công Nghệ</a></li><li class="space"></li>
                                <li><a href="http://115.78.2.62" target="_blank">Tải về</a></li><li class="space"></li>
                                <li><a href="http://forums.buffalotech.com/" target="_blank">Diễn đàn</a></li><li class="space"></li>
                                <li><a href="lienhe.html" id="lienhe" <?php if($_COOKIE['top_nav'] =='lienhe') echo 'class="actived"'; ?> onclick="setCookie('top_nav','lienhe');">Liên Hệ</a></li><li class="space"></li>
                            </ul>
                        </div>
                    </div>
                 </div>
               	
                <div id="container" style="margin-bottom:-15px; clear:both; overflow:hidden;">
                	$body_html
                </div>
              </div>
          </div>
      </div>
  </div>
  <hr>
  <script type="text/javascript">
  function search_info()
  {
	  //alert(document.getElementById('search_phrase').value);
	  $.ajax({
			url: "search.php",
			type: "POST",
			data: "content=" + document.getElementById('search_phrase').value,
			success: function(data){
				if(data != 'Không tìm thấy sản phẩm cần tìm!')
				{
					document.getElementById('container').innerHTML= data;
				}
				if(data == 'Không tìm thấy sản phẩm cần tìm!')
				{
					alert(data);
				}
			}
		});
  }
  
  </script>
<div id="footer">
  <p>© 2008 - 2011 
  Buffalo Technology Vietnam, Inc.
</div>
<!-- /crazyegg --></body></html>